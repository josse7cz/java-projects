package uhk.josef.kanvas.rasterization;

import java.util.List;

/**
 * @author Josef Janda 2016 Interfejs pro vypl�ov�n� scanlinem
 */
public interface PolygonRasterizer {
	PolygonRasterizerScanline drawPolygon(List<Point> points);
	 public interface Line {
	 int getX1();
	 int getY1();
	 int getX2();
	 int getY2();
	 }
}
// public interface PolygonRasterizer {
// public interface Line {
// int getX1();
// int getY1();
// int getX2();
// int getY2();
// }
// PolygonRasterizer drawPolygon(List<Line> edges);
//
// }
//public interface PolygonRasterizer {
//	PolygonRasterizerScanline drawPolygon(List<Point> points);
//
//}