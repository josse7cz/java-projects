package uhk.josef.kanvas;

import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import rendering.Renderer2;
import solids.Cube;
import solids.SimplexPoint3D;
import solids.SolidPoint3D;
import transforms.*;

public class Canvas2 {

	private /* @NotNull */ JFrame frame;
	private /* @NotNull */ JPanel panel;
	private /* @NotNull */ BufferedImage img;
	private final SolidPoint3D cube = new Cube();
	private final SimplexPoint3D simplex = new SimplexPoint3D();
	private final Renderer2 renderer;
	private final Camera cam = new Camera().withPosition(new Vec3D(5, 4, 5)).withAzimuth(Math.PI + Math.atan(4.0 / 5))
			.withZenith(-Math.PI / 4);
	private final Mat4 persp = new Mat4PerspRH(Math.PI / 3, 1.0, 0.1, 100.0);

	public Canvas2(int width, int height) {
		frame = new JFrame();
		frame.setTitle("UHK FIM PGRF : Canvas2");
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar jMenuBar = new JMenuBar();
		JButton butCube = new JButton("Cube");
		jMenuBar.add(butCube);
		JButton butPyr = new JButton("Pyramid");
		jMenuBar.add(butPyr);

		frame.add(jMenuBar, BorderLayout.PAGE_START);
		img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		Graphics lineGraphics = img.getGraphics();
		lineGraphics.setColor(new Color(0xffffffff));
		renderer = new Renderer2(lineGraphics, width, height);

		panel = new JPanel();
		panel.setPreferredSize(new Dimension(width, height));

		frame.add(panel);
		frame.pack();
		frame.setVisible(true);

		class MouseHandler extends MouseAdapter {
			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseReleased(MouseEvent e) {
			}
		}
		panel.addMouseListener(new MouseHandler());
		panel.addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				// tady cam.addAzitmuth(...), cam.addZenith(...)
				cam.addAzimuth(e.getX() * Math.PI / 2);
				// System.out.println("Ahoj");
				cam.addZenith(e.getX() * Math.PI);
				present();
			}
		});

		// panel.addKeyListener(); //cam.forward(0.1)
		frame.addKeyListener(new KeyAdapter() {

			// @Override
			public void keyPressed(KeyEvent e) {
				int keyCode = e.getKeyCode();
				if (keyCode == KeyEvent.VK_UP) {
					cam.forward(0.1);
					System.out.println("up");
				}
				if (keyCode == KeyEvent.VK_DOWN) {
					cam.backward(0.1);
					System.out.println("down");
				}
				if (keyCode == KeyEvent.VK_LEFT) {
					cam.left(0.1);
					System.out.println("left");
				}
				if (keyCode == KeyEvent.VK_RIGHT) {
					cam.right(0.1);
					System.out.println("right");
				}

			}

		});

		butCube.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				clear(0x2f2f2f);
				drawCube();
				present();
			}

		});
		butPyr.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				clear(0x2f2f2f);
				drawPyr();
				present();
			}

		});

	}

	public void clear(int color) {
		Graphics gr = img.getGraphics();
		gr.setColor(new Color(color));
		gr.fillRect(0, 0, img.getWidth(), img.getHeight());
	}

	public void present() {
		if (panel.getGraphics() != null)
			panel.getGraphics().drawImage(img, 0, 0, null);
	}

	public void draw() {
		clear(0x2f2f2f);
		renderer.render(simplex.getVertices(), simplex.getIndices(), cam.getViewMatrix().mul(persp));
		// System.out.println("Ahoj");
	}

	public void drawCube() {
		clear(0x2f2f2f);
		renderer.render(cube.getVertices(), cube.getIndices(), cam.getViewMatrix().mul(persp));
		//
	}
	public void drawPyr() {
		clear(0x2f2f2f);
		renderer.render(simplex.getVertices(), simplex.getIndices(), cam.getViewMatrix().mul(persp));
	}
	public void start() {
		draw();
		present();
	}

	public static void main(String[] args) {
		Canvas2 canvas = new Canvas2(800, 600);
		SwingUtilities.invokeLater(() -> {
			SwingUtilities.invokeLater(() -> {
				SwingUtilities.invokeLater(() -> {
					SwingUtilities.invokeLater(() -> {
						canvas.start();
					});
				});
			});
		});
	}

}