package solids;

import java.util.ArrayList;
import java.util.List;

import transforms.Point3D;

public abstract class SolidPoint3D implements Solid<Point3D> {
	protected final List<Point3D> vertices = new ArrayList<>();//seznam vrchol�
	protected final List<Integer> indices = new ArrayList<>();//spojen� vrchol� do plochy
	@Override
	public List<Point3D> getVertices() {
		return vertices;
	}
	@Override
	public List<Integer> getIndices() {
		return indices;
	}
}
