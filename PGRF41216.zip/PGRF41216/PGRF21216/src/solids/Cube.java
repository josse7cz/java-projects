package solids;

import transforms.Point3D;

public class Cube extends SolidPoint3D {

	public Cube() {
		vertices.add(new Point3D(0, 0, 0));
		vertices.add(new Point3D(1, 0, 0));
		vertices.add(new Point3D(1, 1, 0));
		vertices.add(new Point3D(0, 1, 0));
		vertices.add(new Point3D(0, 0, 1));
		vertices.add(new Point3D(1, 0, 1));
		vertices.add(new Point3D(1, 1, 1));
		vertices.add(new Point3D(0, 1, 1));

//		indices.add(0);// urceni indexu pro kostku
//		indices.add(1);
//		indices.add(1);
//		indices.add(2);
//		indices.add(2);
//		indices.add(3);
//		indices.add(3);
//		indices.add(4);
//		indices.add(4);
//		indices.add(5);
//		indices.add(5);
//		indices.add(6);
//		indices.add(6);
//		indices.add(7);
//		indices.add(3);
//		indices.add(0);
//		indices.add(7);
//		indices.add(4);
//		indices.add(2);
//		indices.add(5);
//		indices.add(1);
//		indices.add(6);
//		indices.add(0);
//		indices.add(7);

		for (int i = 0; i < 4; i++) {
			indices.add(i);
			indices.add((i + 1) % 4);
			indices.add(i);
			indices.add(i + 4);
			indices.add(i + 4);
			indices.add((i + 1) % 4 + 4);
		}
	}

}
