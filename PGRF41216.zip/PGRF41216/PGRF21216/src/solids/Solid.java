package solids;

import java.util.List;

public interface Solid<Vertex> {//teleso
	List<Vertex> getVertices();//vrcholy(vertex buffer)	
	List<Integer> getIndices();//spojen� vrchol� do plochy(index buffer)
}
