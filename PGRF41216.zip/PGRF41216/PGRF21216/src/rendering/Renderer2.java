package rendering;

import java.awt.Graphics;
import java.util.List;
import java.util.Optional;

import transforms.*;

public class Renderer2 {
	private final Graphics graphics;
	private final int width, height;
	public Renderer2(Graphics graphics, int width, int height) {
		this.graphics = graphics;
		this.width = width;
		this.height = height;
	}
	
	public void render(List<Point3D> vertices, List<Integer> indices, 
			Mat4 mat) {
		for (int i = 0; i < indices.size() - 1; i += 2) {
			int i1 = indices.get(i);
			int i2 = indices.get(i + 1);
			Point3D p1 = vertices.get(i1);
			Point3D p2 = vertices.get(i2);
			renderLine(p1, p2, mat);
		}

	}

	private void renderLine(Point3D p1, Point3D p2, Mat4 mat) {
		final Point3D tp1 = p1.mul(mat);
		final Point3D tp2 = p2.mul(mat);
		if (tp1.getW() <= 0 || tp2.getW() <= 0) return;
		final Optional<Vec3D> dp1 = tp1.dehomog();
		final Optional<Vec3D> dp2 = tp2.dehomog();
		dp1.ifPresent((final Vec3D v1) -> {
			dp2.ifPresent(v2 -> {
				drawLine(v1, v2);
			});
		});
	}
	private void drawLine(final Vec3D p1, final Vec3D p2) {
		final int x1 =(int) ((p1.getX() + 1) * 0.5 * (width - 1));
		final int y1 = (int) ((-p1.getY() + 1) * 0.5 * (height - 1));
		final int x2 = (int) ((p2.getX() + 1) * 0.5 * (width - 1));
		final int y2 = (int) ((-p2.getY() + 1) * 0.5 * (height - 1));
		//TODO zrusit BufferedImage, predelat na LineRasterizer
		graphics.drawLine(x1, y1, x2, y2);

	}
	
}

