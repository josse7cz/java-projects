package rendering;

import java.util.List;

import transforms.Mat4;//r�zn� transformace t�lesa �um�st�n�, velikost, rotace

public interface Renderer<V> {//konvence typove parametry znacit jednim velkym pismenem tedy V=Vertex,I=Image
	enum PrimitiveType { LINE_LIST, TRIANGLE_LIST };
	void render(List<V> vertices, List<Integer> indices, int startIndex, int indexCount, PrimitiveType type, 
			Mat4 mat);
}